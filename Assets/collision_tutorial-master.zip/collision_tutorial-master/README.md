# Collision Tutorial
2d platformer stomp collision tutorial  

[![IMAGE ALT](https://img.youtube.com/vi/3rrPr90Oras/0.jpg)](https://www.youtube.com/watch?v=3rrPr90Oras)  
YouTube - https://youtu.be/3rrPr90Oras

# List of all my Godot project:
https://github.com/sheetcode/GodotProjects
